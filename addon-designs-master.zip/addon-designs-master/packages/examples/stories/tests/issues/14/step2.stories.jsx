import React from "react";

import { Button } from "../../../Button";

export default {
  title: "Tests/Issues/#14/Step2",
};

export const step2 = () => <Button>Button</Button>;

step2.storyName = "Do not persist addon panel";
