import { register } from "./manager/register";

register("tab");
