import { register } from "./manager/register";

register("panel");
