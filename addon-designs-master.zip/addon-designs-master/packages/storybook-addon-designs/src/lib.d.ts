declare module "!!file-loader!*" {
  const path: string;
  export default path;
}
