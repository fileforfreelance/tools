# CHANGELOG.md

See `@storybook/addon-designs` [CHANGELOG.md](./packages/storybook-addon-designs/CHANGELOG.md).

For older versions, see [CHANGELOG.v1-6.md](./CHANGELOG.v1-6.md).
